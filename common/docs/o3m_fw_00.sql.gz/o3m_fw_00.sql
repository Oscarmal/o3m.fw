-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: 192.168.230.28    Database: o3m_fw_00
-- ------------------------------------------------------
-- Server version	5.1.37-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sis_empresas`
--

DROP TABLE IF EXISTS `sis_empresas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sis_empresas` (
  `id_empresa` mediumint(6) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE utf8_spanish_ci DEFAULT NULL,
  `siglas` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `rfc` varchar(18) COLLATE utf8_spanish_ci DEFAULT NULL,
  `razon` varchar(200) COLLATE utf8_spanish_ci DEFAULT NULL,
  `direccion` text COLLATE utf8_spanish_ci,
  `pais` varchar(15) COLLATE utf8_spanish_ci DEFAULT 'MX',
  `email` varchar(80) COLLATE utf8_spanish_ci DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT '1',
  `id_nomina` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_empresa`),
  KEY `i_nomina` (`id_nomina`)
) ENGINE=MyISAM AUTO_INCREMENT=195 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sis_empresas`
--

LOCK TABLES `sis_empresas` WRITE;
/*!40000 ALTER TABLE `sis_empresas` DISABLE KEYS */;
INSERT INTO `sis_empresas` VALUES (1,'Desarrollo IS','Develop',NULL,'iSolution.mx',NULL,'MX','oscar.maldonado@isolution.mx',NULL,0,1,0);
/*!40000 ALTER TABLE `sis_empresas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sis_grupos`
--

DROP TABLE IF EXISTS `sis_grupos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sis_grupos` (
  `id_grupo` tinyint(2) NOT NULL,
  `grupo` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `mod1` tinyint(1) NOT NULL DEFAULT '0',
  `mod2` tinyint(1) NOT NULL DEFAULT '0',
  `mod3` tinyint(1) NOT NULL DEFAULT '0',
  `mod4` tinyint(1) NOT NULL DEFAULT '0',
  `mod5` tinyint(1) NOT NULL DEFAULT '0',
  `mod6` tinyint(1) NOT NULL DEFAULT '0',
  `mod7` tinyint(1) NOT NULL DEFAULT '0',
  `mod8` tinyint(1) NOT NULL DEFAULT '0',
  `mod9` tinyint(1) NOT NULL DEFAULT '0',
  `mod10` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_grupo`)
) ENGINE=MyISAM AUTO_INCREMENT=71 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sis_grupos`
--

LOCK TABLES `sis_grupos` WRITE;
/*!40000 ALTER TABLE `sis_grupos` DISABLE KEYS */;
INSERT INTO `sis_grupos` VALUES (10,'administradores',1,1,1,1,1,1,1,1,1,1),(20,'inplant',1,0,0,1,1,1,1,0,0,0),(30,'nivel5',1,0,1,1,1,0,0,0,0,0),(40,'nivel2',1,0,1,1,0,0,0,0,0,0),(50,'nivel1',1,0,1,1,0,0,0,0,0,0),(60,'empleados',1,1,0,1,0,0,0,0,0,0),(70,'extra',1,0,0,0,0,0,0,0,0,0),(0,'root',1,1,1,1,1,1,1,1,1,1),(21,'global',1,1,1,1,1,0,1,0,0,0),(35,'nivel3',1,0,1,1,1,0,0,0,0,0),(34,'nivel4',1,0,1,1,1,0,0,0,0,0);
/*!40000 ALTER TABLE `sis_grupos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sis_logs`
--

DROP TABLE IF EXISTS `sis_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sis_logs` (
  `id_log` int(11) NOT NULL AUTO_INCREMENT,
  `tablename` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `id_table` int(11) DEFAULT NULL,
  `accion` enum('UPDATE','DELETE','INSERT') COLLATE utf8_spanish_ci DEFAULT NULL,
  `query` text COLLATE utf8_spanish_ci,
  `txt` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `url` text COLLATE utf8_spanish_ci,
  `timestamp` datetime DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_log`),
  KEY `id_usuario` (`id_usuario`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sis_logs`
--

LOCK TABLES `sis_logs` WRITE;
/*!40000 ALTER TABLE `sis_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `sis_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sis_modulos`
--

DROP TABLE IF EXISTS `sis_modulos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sis_modulos` (
  `id_modulo` smallint(3) NOT NULL AUTO_INCREMENT,
  `id_nivel` smallint(3) DEFAULT '0',
  `modulo` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `icono` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `id_superior` smallint(3) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id_modulo`),
  KEY `i_nivel` (`id_nivel`),
  KEY `i_superior` (`id_superior`),
  KEY `i_activo` (`activo`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sis_modulos`
--

LOCK TABLES `sis_modulos` WRITE;
/*!40000 ALTER TABLE `sis_modulos` DISABLE KEYS */;
INSERT INTO `sis_modulos` VALUES (1,0,'ADMINISTRACION',NULL,NULL,1),(2,0,'INICIO',NULL,NULL,1),(3,0,'CAPTURA',NULL,NULL,1),(4,0,'CONSULTA',NULL,NULL,1),(5,0,'REPORTES',NULL,NULL,1);
/*!40000 ALTER TABLE `sis_modulos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sis_online`
--

DROP TABLE IF EXISTS `sis_online`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sis_online` (
  `id_online` mediumint(4) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) DEFAULT NULL,
  `online` int(12) DEFAULT NULL,
  PRIMARY KEY (`id_online`),
  KEY `i_usuario` (`id_usuario`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sis_online`
--

LOCK TABLES `sis_online` WRITE;
/*!40000 ALTER TABLE `sis_online` DISABLE KEYS */;
/*!40000 ALTER TABLE `sis_online` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sis_personal`
--

DROP TABLE IF EXISTS `sis_personal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sis_personal` (
  `id_personal` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(32) COLLATE utf8_spanish_ci DEFAULT NULL,
  `paterno` varchar(32) COLLATE utf8_spanish_ci DEFAULT NULL,
  `materno` varchar(32) COLLATE utf8_spanish_ci DEFAULT NULL,
  `rfc` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `imss` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `email` varchar(80) COLLATE utf8_spanish_ci DEFAULT NULL,
  `sucursal` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `puesto` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `empleado_num` int(11) DEFAULT NULL,
  `id_empresa` smallint(4) DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT '1',
  `id_nomina` int(11) DEFAULT NULL,
  `estado` varchar(80) COLLATE utf8_spanish_ci DEFAULT NULL,
  `sucursal_nomina` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id_personal`),
  KEY `i_empresa` (`id_empresa`),
  KEY `i_activo` (`activo`),
  KEY `i_puesto` (`id_empresa`,`puesto`),
  KEY `i_empleado_num` (`empleado_num`),
  KEY `fk_usuario` (`id_usuario`),
  KEY `i_nomina` (`id_nomina`),
  KEY `i_estado` (`estado`)
) ENGINE=MyISAM AUTO_INCREMENT=783 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sis_personal`
--

LOCK TABLES `sis_personal` WRITE;
/*!40000 ALTER TABLE `sis_personal` DISABLE KEYS */;
INSERT INTO `sis_personal` VALUES (1,'Root','del','sistema','','','oscar.maldonado@isolution.mx','','Root',0,1,NULL,NULL,1,0,NULL,NULL),(2,'Administrador','PAE','sistema','','','oscar.maldonado@isolution.mx','','Administrador',0,1,NULL,NULL,1,0,NULL,NULL),(3,'Inplant','del','cliente','','','oscar.maldonado@isolution.mx','CHRYSLER SANTA.FE','Inplant',0,41,NULL,NULL,1,0,NULL,NULL),(4,'Nivel5','del','cliente','','','oscar.maldonado@isolution.mx','CHRYSLER SANTA.FE','Nivel5',0,41,NULL,NULL,0,0,NULL,NULL),(5,'Nivel4','del','cliente','','','oscar.maldonado@isolution.mx','CHRYSLER SANTA.FE','Nivel4',0,41,NULL,NULL,0,0,NULL,NULL),(6,'Nivel3','de','cliente','','','oscar.maldonado@isolution.mx','CHRYSLER SANTA.FE','Nivel3',0,41,'2015-07-13 12:58:54',2,1,0,NULL,NULL),(7,'Nivel2','del','cliente','','','oscar.maldonado@isolution.mx','CHRYSLER SANTA.FE','Nivel2',0,41,NULL,NULL,1,0,NULL,NULL),(8,'Nivel1','del','cliente','','','oscar.maldonado@isolution.mx','CHRYSLER SANTA.FE','Nivel1',0,41,NULL,NULL,1,0,NULL,NULL),(9,'Empleado ','Del','Cliente','','','oscar.maldonado@isolution.mx','PRUEBAS','Empleado',0,41,'2015-03-19 14:08:26',3,1,0,'CIUDAD DE MÉXICO','COORPORATIVO'),(10,'Usuario','Global','del Cliente','','','oscar.maldonado@isolution.mx','CHRYSLER SANTA.FE','Global',0,41,NULL,NULL,0,0,NULL,NULL);
/*!40000 ALTER TABLE `sis_personal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sis_usuarios`
--

DROP TABLE IF EXISTS `sis_usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sis_usuarios` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `clave` varchar(32) COLLATE utf8_spanish_ci DEFAULT NULL,
  `id_grupo` tinyint(2) DEFAULT '60',
  `id_personal` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `activo` tinyint(1) DEFAULT '1',
  `login` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id_usuario`),
  KEY `i_grupo` (`id_grupo`),
  KEY `i_activo` (`activo`),
  KEY `i_personal` (`id_personal`)
) ENGINE=MyISAM AUTO_INCREMENT=775 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sis_usuarios`
--

LOCK TABLES `sis_usuarios` WRITE;
/*!40000 ALTER TABLE `sis_usuarios` DISABLE KEYS */;
INSERT INTO `sis_usuarios` VALUES (1,'root','63a9f0ea7bb98050796b649e85481845',0,1,NULL,1,1),(2,'admin','21232f297a57a5a743894a0e4a801fc3',10,2,NULL,1,1),(3,'inplant','d3136ade621c131e74a833684324cd3f',20,3,NULL,1,1),(4,'nivel5','75edac518e49dbc4b6930f0c76c27569',30,4,NULL,1,0),(5,'nivel4','fd57d7925c772b24bf450663508230de',34,5,NULL,1,1),(6,'nivel3','f4d49413fb521f083563646b8054e3e9',35,6,NULL,1,1),(7,'nivel2','19726b6c8dfe0a48bac15542db28134c',40,7,NULL,1,1),(8,'nivel1','cd000523267ff95b50c356f0d6f67703',50,8,NULL,1,1),(9,'empleado','088ef99bff55c67dc863f83980a66a9b',60,9,NULL,1,1),(10,'global','9c70933aff6b2a6d08c687a6cbb6b765',21,10,NULL,1,1);
/*!40000 ALTER TABLE `sis_usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-12 12:06:22
